/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['www.icj-cij.org', 'images.unsplash.com'],
  },
}

export default nextConfig
